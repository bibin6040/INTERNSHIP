from django.db import models
class login(models.Model):
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)

class Register(models.Model):
    name=models.CharField(max_length=30)
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)