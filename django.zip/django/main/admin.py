from django.contrib import admin
from main.models import login
admin.site.register(login)
from main.models import Register
admin.site.register(Register)